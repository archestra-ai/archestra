# payments-service

Card charging for pilot tenants. `chargeCard` validates the request, then posts
the charge to the PSP with an idempotency key, retrying transient failures with
exponential backoff.
