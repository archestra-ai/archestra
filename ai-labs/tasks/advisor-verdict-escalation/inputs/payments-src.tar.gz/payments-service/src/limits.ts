import type { ChargeRequest } from "./charge";

const MAX_CHARGE_CENTS = 500_000;
const SUPPORTED_CURRENCIES = new Set(["USD", "EUR", "PLN"]);

export function assertChargeable(req: ChargeRequest): void {
  if (!Number.isInteger(req.amountCents) || req.amountCents <= 0) {
    throw new RangeError(`amountCents must be a positive integer, got ${req.amountCents}`);
  }
  if (req.amountCents > MAX_CHARGE_CENTS) {
    throw new RangeError(`amountCents ${req.amountCents} exceeds the per-charge cap ${MAX_CHARGE_CENTS}`);
  }
  if (!SUPPORTED_CURRENCIES.has(req.currency)) {
    throw new RangeError(`unsupported currency ${req.currency}`);
  }
  if (!req.customerId.startsWith("cus_")) {
    throw new RangeError("customerId is not a customer token");
  }
}
