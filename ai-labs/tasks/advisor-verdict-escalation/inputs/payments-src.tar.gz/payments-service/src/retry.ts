import { PspConnectionError, PspTimeoutError } from "./psp-client";

const MAX_ATTEMPTS = 3;
const BASE_BACKOFF_MS = 200;

export async function withRetry<T>(fn: () => Promise<T>): Promise<T> {
  let lastError: unknown;
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;
      if (!isRetryable(error) || attempt === MAX_ATTEMPTS) {
        throw error;
      }
      await sleep(BASE_BACKOFF_MS * 2 ** (attempt - 1));
    }
  }
  throw lastError;
}

// Connection drops and gateway timeouts are transient; anything the PSP
// answered (4xx/5xx with a body) is not retried.
function isRetryable(error: unknown): boolean {
  return error instanceof PspTimeoutError || error instanceof PspConnectionError;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
