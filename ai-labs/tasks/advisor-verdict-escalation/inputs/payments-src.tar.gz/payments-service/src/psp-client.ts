const REQUEST_TIMEOUT_MS = 10_000;

export class PspTimeoutError extends Error {}
export class PspConnectionError extends Error {}
export class PspApiError extends Error {
  constructor(
    public readonly status: number,
    message: string,
  ) {
    super(message);
  }
}

export interface PspRequestOptions {
  method: "GET" | "POST";
  body?: unknown;
}

export async function pspRequest<T>(path: string, options: PspRequestOptions): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(`${process.env.PSP_BASE_URL}${path}`, {
      method: options.method,
      headers: { "Content-Type": "application/json" },
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
      signal: controller.signal,
    });
    if (!response.ok) {
      throw new PspApiError(response.status, await response.text());
    }
    return (await response.json()) as T;
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new PspTimeoutError(`PSP request to ${path} timed out after ${REQUEST_TIMEOUT_MS}ms`);
    }
    if (error instanceof TypeError) {
      throw new PspConnectionError(`PSP request to ${path} failed to connect`);
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}
