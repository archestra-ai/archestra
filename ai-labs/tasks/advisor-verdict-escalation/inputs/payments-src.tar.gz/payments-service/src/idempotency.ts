import { randomUUID } from "node:crypto";

// A unique key per charge so the PSP can de-duplicate replays of the same request.
export function makeIdempotencyKey(): string {
  return `chg_${Date.now()}_${randomUUID()}`;
}
