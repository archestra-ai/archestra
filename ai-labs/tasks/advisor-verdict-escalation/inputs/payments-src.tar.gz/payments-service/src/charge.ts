import { pspRequest } from "./psp-client";
import { makeIdempotencyKey } from "./idempotency";
import { assertChargeable } from "./limits";
import { withRetry } from "./retry";

export interface ChargeRequest {
  customerId: string;
  amountCents: number;
  currency: string;
}

export interface ChargeResult {
  chargeId: string;
  status: "succeeded" | "pending";
}

export async function chargeCard(req: ChargeRequest): Promise<ChargeResult> {
  assertChargeable(req);
  return withRetry(() =>
    pspRequest<ChargeResult>("/v1/charges", {
      method: "POST",
      body: {
        customer_id: req.customerId,
        amount_cents: req.amountCents,
        currency: req.currency,
        idempotency_key: makeIdempotencyKey(),
      },
    }),
  );
}
