# Herdr v0.9.0 Linux collected license and notice bundle

Source: b99002ac99b09e00b4ca692436cb15a6b0d676f1. Collected 2026-09-16 for the x86_64 and aarch64 MUSL release binaries listed in ../artifact-inventory.json.

Include this directory, or an equivalently accessible third-party-notices document with these applicable texts, alongside Herdr in redistributed images. A suggested location is /usr/share/licenses/herdr/. Keep the Herdr Apache-2.0 text and applicable third-party copyright/permission notices. Preserve modifications notices if distributing modified source. No source-publication duty for Archestra was identified in the examined Linux components.

This bundle conservatively includes license texts for all 205 resolved Cargo graph nodes (204 third-party packages plus Herdr), including build-only dependencies; native Ghostty, portable-pty, uucode, Highway, and simdutf; and Rust/Zig/MUSL/LLVM runtime notice material. It is collected notice material, not an assertion every named package is present in the final executable. MIT is a permitted choice where crates offer MIT OR Apache; other OR choices and any AND requirements remain governed by each included text. Include all relevant Unicode and embedded BSD notices.

Rust COPYRIGHT-library.html is the exact 1.96.1 standard-library notice document from the official rustc component. It covers multiple targets. Its MPL-2.0 fortanix-sgx-abi entry is SGX-only (Rust library/std/Cargo.toml target.x86_64-fortanix-unknown-sgx), not either Linux MUSL target. Likewise it contains optional LGPL alternatives, not mandatory LGPL for these binaries. LLVM C++/unwind notices and uucode comparison-resource notices are conservative inclusions; they should not be mistaken for evidence that all those files were linked.

Crate archives omitted seven root license texts: five Ratatui crates, vtparse, wezterm-input-types. UPSTREAM-* files were recovered from the exact source commit recorded in each archive's .cargo_vcs_info.json. Other crate texts come from Cargo checksum-verified archive extraction. simdutf's Zig manifest says 5.2.8 but the vendored header identifies 9.0.0; its upstream v9.0.0 license texts plus embedded BSD notice are included. The vendored amalgamation is reduced/customized, not byte-identical to upstream full amalgamation.

No Wuffs notice is required on the observed v0.9.0 library build path: Ghostty disables its default decoder for library mode and Herdr registers Rust png. This does not characterize later master versions.

The sound assets were introduced by upstream maintainer commit 0403775fd2a9458417c5349d5441125ab9b2553c and are included under the repository's Apache-2.0 offer; no separate asset attribution/restrictive terms were found. Independent ownership proof is not provided by source history. Normal upstream-license reliance, not a verified chain-of-title warranty, is the basis for including them.

This bundle does not license the rest of the Archestra base image or agent executables. It was not tested by executing the untrusted Herdr binaries, and no exact reproducible build or link-map SBOM was produced.

GCC 9.4.0 COPYING3 and COPYING.RUNTIME are included conservatively because the inspected executable comment strings contain GCC 9.4.0. That string alone does not establish which GCC runtime object files are linked. The published source build uses standard Rust/Cargo + Zig + system linkers. GCC's Runtime Library Exception permits eligible target-code combinations under the independent modules' terms; there is no observed proprietary GCC-IR plugin or other ineligible compilation process. No claim is made that all GCC runtime source belongs in Herdr's SBOM.
